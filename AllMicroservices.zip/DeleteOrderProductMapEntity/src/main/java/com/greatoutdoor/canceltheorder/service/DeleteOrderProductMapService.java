package com.greatoutdoor.canceltheorder.service;

public interface DeleteOrderProductMapService {
	
	
	boolean deleteOrderProductMapEntity(String orderId);
}
