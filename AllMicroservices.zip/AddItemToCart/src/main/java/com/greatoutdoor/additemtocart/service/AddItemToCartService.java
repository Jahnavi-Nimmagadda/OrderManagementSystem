package com.greatoutdoor.additemtocart.service;

import com.greatoutdoor.additemtocart.entities.CartDTO;


public interface AddItemToCartService {

	boolean addItemToCart(CartDTO cart);
}
