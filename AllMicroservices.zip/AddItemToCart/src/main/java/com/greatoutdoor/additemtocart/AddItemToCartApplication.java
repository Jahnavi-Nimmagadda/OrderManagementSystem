package com.greatoutdoor.additemtocart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AddItemToCartApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddItemToCartApplication.class, args);
	}

}
