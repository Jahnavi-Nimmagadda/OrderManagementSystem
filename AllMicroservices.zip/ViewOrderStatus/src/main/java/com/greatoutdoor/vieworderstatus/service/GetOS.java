package com.greatoutdoor.vieworderstatus.service;



public interface GetOS {
	
	Object viewOrderStatus(String userId);
}
