package com.greatoutdoor.canceltheproduct.service;

public interface RemoveItemService {
	
	

	boolean removeItemFromCart(String productId, String userId);
}
